// service-worker.js
// The extension's background script. Handles data loading and context menu activation.

// --- CONFIGURATION (No API Key needed) ---
// const GEMINI_API_KEY = "..."; // DELETED
// const API_BASE_URL = "..."; // DELETED

// Global variables to hold the loaded Eco-Score data
let ecoScoreDB = null; 
let materialKeys = []; 

// Helper to load the JSON data from the bundled file
async function loadEcoScoreData() {
    try {
        const response = await fetch(chrome.runtime.getURL('ecoScoreDB.json'));
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        ecoScoreDB = await response.json();
        // Create an array of standardized keys (e.g., "Polyester")
        materialKeys = Object.keys(ecoScoreDB); 
        console.log("Eco-Score database loaded successfully.");
    } catch (error) {
        console.error("Failed to load Eco-Score database:", error);
        
        // TEMPORARY FALLBACK: Minimal structure if JSON fails to load
        ecoScoreDB = {
            "Polyester": { "score": 30, "alternatives": [] }, 
            "Cotton": { "score": 60, "alternatives": [] }, 
            "Default": { "score": 50, "alternatives": [] }
        };
        materialKeys = Object.keys(ecoScoreDB); 
        console.warn("Using minimal hardcoded database due to JSON load failure.");
    }
}

// Helper to send message to the currently open side panel for a specific tab
async function sendMessageToSidePanel(tabId, message) {
    try {
        await chrome.tabs.get(tabId); 
        await chrome.runtime.sendMessage({ ...message, panel: true, targetTabId: tabId });
    } catch (e) {
        // Expected if the side panel is closed
    }
}


// --- API Call Function is DELETED ---


// Runs once when the extension is installed or updated
chrome.runtime.onInstalled.addListener(async () => {
    await loadEcoScoreData();
    await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });

    chrome.sidePanel.setOptions({
        path: "sidepanel.html",
        enabled: true
    });
    
    chrome.contextMenus.create({
        id: "ecoCheckerScan",
        title: "EcoChecker: Check Material Sustainability",
        contexts: ["selection"] 
    });
});


// Listen for a click on the context menu item (The main trigger)
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
    if (!ecoScoreDB) {
        await sendMessageToSidePanel(tab.id, { action: "updateUI", status: "Error: Database not loaded. Please restart extension." });
        return;
    }
    
    if (info.menuItemId === "ecoCheckerScan" && info.selectionText) {
        await chrome.sidePanel.open({ tabId: tab.id });

        let selectedText = info.selectionText.trim().toLowerCase();
        
        // --- Material Name Standardization (Robust Logic) ---
        let materialName = 'Unknown Material';
        let materialLookupKey = 'Default';

        // Find the best match by checking if the selected text CONTAINS a key
        for (const key of materialKeys) {
            const lowerKey = key.toLowerCase();
            
            if (selectedText.includes(lowerKey)) {
                materialName = key; // Use the exact capitalized key for display
                materialLookupKey = key; 
                break; // Found the best match
            }
        }
        
        // 1. Lookup the entire material object
        const materialData = ecoScoreDB[materialLookupKey];
        const ecoScore = materialData.score;
        const alternatives = materialData.alternatives;

        // 2. Send initial score update to the side panel
        await sendMessageToSidePanel(tab.id, { 
            action: "updateUI", 
            status: `Selected Material: **${materialName}**. Eco-Score: ${ecoScore}/100`, 
            score: ecoScore,
            material: materialName
        });

        // 3. Check for and send alternatives locally
        if (ecoScore < 50 && alternatives && alternatives.length > 0) {
             await sendMessageToSidePanel(tab.id, { 
                action: "alternativesFound", 
                alternatives: alternatives,
                material: materialName
            });
        } else {
            await sendMessageToSidePanel(tab.id, { action: "updateUI", status: `**${materialName}** has a good score. No alternatives needed.` });
        }
    }
});