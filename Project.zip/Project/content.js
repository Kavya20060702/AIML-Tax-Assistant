// content.js
// Runs on the current webpage to find and extract the product material,
// primarily for the new 'Auto-Scan' feature.

/**
 * Searches the visible text of the DOM for common material names.
 * This method is generally robust across complex e-commerce sites.
 * @returns {string|null} The normalized material name (e.g., "Cotton", "Nylon"), or null if not found.
 */
function findProductMaterial() {
    // List of common materials, standardized to lowercase for search
    const commonMaterials = [
        'organic cotton', 'recycled cotton', 'cotton', 
        'recycled polyester', 'polyester', 
        'wool', 'cashmere', 'silk', 
        'linen', 'hemp', 'jute', 
        'ecolife', 'nylon', 'lyocell', 'tencel', 
        'modal', 'rayon', 'viscose', 
        'spandex', 'elastane', 'leather'
    ];
    
    // Create a robust search pattern:
    // Group 1: Optional percentage (e.g., "100% ")
    // Group 2: The material name (using the joined list of materials)
    // Word boundaries (\b) ensure "poly" doesn't match "polyester"
    const materialRegex = new RegExp(`(?:\\d+\\%\\s*)?\\b(${commonMaterials.join('|')})\\b`, 'i');
    
    // Search the whole body text. innerText is preferred over textContent as it only includes visible text.
    const bodyText = document.body.innerText;
    let match = bodyText.match(materialRegex);

    if (match) {
        // match[1] contains the actual matched material name (e.g., 'polyester')
        let material = match[1];
        
        // Normalize the name by capitalizing the first letter of each word (e.g., "organic cotton" -> "Organic Cotton")
        const normalizedMaterial = material.toLowerCase().split(' ').map(
            (word) => word.charAt(0).toUpperCase() + word.slice(1)
        ).join(' ');

        return normalizedMaterial;
    }
    
    // If no material is found
    return null; 
}


// Listen for the 'scanPageForMaterial' message from the Service Worker.
// We check for the ready state to ensure all necessary DOM content is loaded.
if (document.readyState === 'complete') {
    listenForScanRequest();
} else {
    window.addEventListener('load', listenForScanRequest);
}

function listenForScanRequest() {
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
        if (request.action === "scanPageForMaterial") {
            
            // 1. Attempt to find the material
            const material = findProductMaterial(); 
            
            // 2. Send the found material (or null) back to the service worker
            chrome.runtime.sendMessage({
                action: "materialFound",
                material: material, 
                tabId: request.tabId 
            });

            // Acknowledge the request
            sendResponse({status: "Scan initiated and message sent"});
        }
        return true; 
    });
}